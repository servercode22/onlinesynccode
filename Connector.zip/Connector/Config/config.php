<?php

return [
    'name' => 'Connector',
    'module_version' => "1.7",
    'pid' => 9
];
